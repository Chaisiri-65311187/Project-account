import 'package:flutter/material.dart';
import '../model/deviceItem.dart';

class DeviceProvider with ChangeNotifier {
  final List<DeviceItem> _devices = [];
  int _idCounter = 0;

  List<DeviceItem> get devices => _devices;

  void addDevice(String name, String brand) {
    final newDevice = DeviceItem(
      id: (_idCounter++).toString(),
      name: name,
      brand: brand,
    );
    _devices.add(newDevice);
    notifyListeners();
  }

  void toggleDevice(String id) {
    final index = _devices.indexWhere((device) => device.id == id);
    if (index != -1) {
      _devices[index].isOn = !_devices[index].isOn;
      notifyListeners();
    }
  }

  void updateDevice(String id, String newName, String newBrand) {
    final index = _devices.indexWhere((device) => device.id == id);
    if (index != -1) {
      _devices[index].name = newName;
      _devices[index].brand = newBrand;
      notifyListeners();
    }
  }

  void removeDevice(String id) {
    _devices.removeWhere((device) => device.id == id);
    notifyListeners();
  }
}
